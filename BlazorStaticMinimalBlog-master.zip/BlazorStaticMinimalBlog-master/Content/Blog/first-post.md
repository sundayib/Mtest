---
title: First post
lead: Sample post so you can see how it works
published: 2023-11-04
tags: [tag-001, another-sample-tag]
authors:
    - name: "Jan Tesař"
      gitHubUserName: "tesar-tech"
      xUserName: "tesar_tech"
---

Hi, this is a sample post with front matter (YAML) metadata. You can use Markdown to write your content.
Also here is a sample image:

![programming bug](media/programming_bug.jpg)


